"""nbconvert cli entry point."""
from .nbconvertapp import main

main()
