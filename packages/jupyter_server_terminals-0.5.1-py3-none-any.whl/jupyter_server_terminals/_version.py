"""Version info for jupyter_server_terminals."""
__version__ = "0.5.1"
